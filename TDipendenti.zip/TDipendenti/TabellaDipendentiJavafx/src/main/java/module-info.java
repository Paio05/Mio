module com.example.tabelladipendentijavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.tabelladipendentijavafx to javafx.fxml;
    exports com.example.tabelladipendentijavafx;
}